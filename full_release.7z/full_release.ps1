#provide input for sdc_url,console_url,sdms_instance, type and web_config.
$sdc_url = "http://downloads.dev.support.com/package/sdcinstall/v76/sdcinstall_76.0.11.0.7z.exe"
$console_url = "http://downloads.dev.support.com/package/console/v76/console_incontact_76.0.6.0.zip"
$sdc_url_parts = $sdc_url.split("/")
$m = $sdc_url_parts.length
$build = $sdc_url_parts[$m-1]
$console_url_parts = $console_url.split("/")
$n = $console_url_parts.length
$pack = $console_url_parts[$n-1]
$major_version = $sdc_url_parts[$m-2]
$sdms_instance = "SaaS" #give Value as Prod for Prod/Care
$downloadDir = ""
$storageDir = ""
$string = "Release" #user input not required
$type = "stage"
$web_config = "\\any.network.share\d$\jenkins\workspace\prod\web.config" #this template file contains ninjato vpn whitelisting. To avoid writing
#whitelisting into all machines after install, we copy the template into the sdc folder before we push it to app servers

if($sdms_instance -eq "Prod"){
    write-host "D:\sdc\download\prod\$major_version" #change path as per your convenience
    $downloadDir = "D:\sdc\download\prod\$major_version$string"
}

if($sdms_instance -eq "SaaS"){
    $downloadDir = "D:\sdc\download\ustech\$major_version$string"
}

write-host $downloadDir #to check if download directory is created in the right place

if(!(Test-Path -Path $downloadDir)){
    Invoke-Expression "mkdir $downloadDir"
}

$build_exe = "$downloadDir\$build"
$console_package = "$downloadDir\$pack"
$webclient = New-Object System.Net.WebClient


IF(!([string]::IsNullOrEmpty($sdc_url))){
    $webclient.DownloadFile($sdc_url,$build_exe)
    write-host "finished downloading sdc"
 }
IF(!([string]::IsNullOrEmpty($console_url))){
    $webclient.DownloadFile($console_url,$console_package)
    write-host "findished downloading console package"
}


$build_dir = $build.Replace(".7z.exe","")
$build_dir1 =  "$downloadDir\$build_dir"
$sz= "C:\Program Files\7-zip\7z.exe" #configure 7zip executable path
$targetConsoleDir = "$downloadDir\final_patch"


& $sz x $console_package "-o$targetConsoleDir" # extract the console package into a temp folder

Set-Location -Path $downloadDir
Get-Location
cmd /c $build # run sdcinstall

cmd /c xcopy $targetConsoleDir $build_dir1 /EYF # copy the contents of console package into sdcinstall folder

if($sdms_instance -eq "Prod"){
	Copy-Item $web_config -Destination $build_dir1\root\www -verbose -Force # copy the web.config into sdcinstall\root\www only incase of prod/care
}

if($sdms_instance -eq "Prod") {
	$computers =  "D:\sdc\prod_$type.txt" # use relevant file to get list of servers either for stage or production. $type determines the list
	#file should contain values like \\172.0.0.0\sdc\
}
else{
	$computers = "D:\sdc\saas_$type.txt"
}

Get-Content $Computers | foreach { write $_
copy-item $build_dir1 -Destination \\$_\$build_dir\ -recurse # copy the sdc build across all app servers
}


